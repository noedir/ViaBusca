-- phpMyAdmin SQL Dump
-- version 2.9.2
-- http://www.phpmyadmin.net
-- 
-- Máquina: localhost
-- Data de Criação: 14-Out-2012 às 17:11
-- Versão do servidor: 5.5.24
-- versão do PHP: 5.3.10-1ubuntu3.4
-- 
-- Base de Dados: `viabusca`
-- 

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `tbl_acre`
-- 

CREATE TABLE `tbl_acre` (
  `acr_codigo` bigint(20) NOT NULL AUTO_INCREMENT,
  `acr_url` varchar(250) DEFAULT NULL,
  `acr_indexado` enum('s','n') DEFAULT 'n',
  PRIMARY KEY (`acr_codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `tbl_site`
-- 

CREATE TABLE `tbl_site` (
  `sit_codigo` bigint(20) NOT NULL AUTO_INCREMENT,
  `sit_titulo` varchar(250) DEFAULT NULL,
  `sit_url` varchar(250) DEFAULT NULL,
  `sit_metakey` text,
  `sit_metades` text,
  `sit_relevancia` bigint(20) DEFAULT '0',
  `sit_idioma` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`sit_codigo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;
